package com.example.kisiidsc;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    //Declaring the android widgets
    private Button buttonRegister;
    private EditText editTextPasssword;
    private EditText editTextEmail;
    private TextView textViewSingin;

    private ProgressDialog progressDialog;

    //Firebase authentication object
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // we are initializing firebase athentication object
        firebaseAuth = FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser() != null){
            finish();
            startActivity(new Intent(getApplicationContext(),DSCKISII.class));
        }

        progressDialog = new ProgressDialog(this);

        buttonRegister = (Button) findViewById(R.id.buttonRegister);
        editTextPasssword = (EditText) findViewById(R.id.editTextPassword);
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        textViewSingin = (TextView) findViewById(R.id.textViewSignin);

        buttonRegister.setOnClickListener(this);
        textViewSingin.setOnClickListener(this);

    }

    //this is the method used to register the user
    private void registerUser(){
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPasssword.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            Toast.makeText(this, "PLease enter your Email", Toast.LENGTH_SHORT).show();
            return; // stops this function from executing further

        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show();
            return; // stops this function from executing further

        }

        // I am using a progress dialog to show that the user is registering since internet  might be slow
        progressDialog.setMessage("Registering...");
        progressDialog.show();


        //this method creates a user in the console with a given email and password
        firebaseAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(MainActivity.this, "Registration Successfull", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();

                            finish();
                            startActivity(new Intent(getApplicationContext(),DSCKISII.class));

                        }
                        else{
                            Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }

                    }
                });


    }

    @Override
    public void onClick(View view) {

        if(view == buttonRegister){
            //when the register button is pressed this function is executed,this fucntion registers the users
            registerUser();
        }
        if(view == textViewSingin){
            finish();
            //opens login activity
            startActivity(new Intent(this, Login.class));
        }

    }


}

